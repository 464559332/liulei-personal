
package org.tech.frontier.utils;

public final class Constants {
    public static final String APP_KEY = "1044594671";
    public static final String APP_SECRET = "ad29ec78e297ce52897e298b393b540d";
    public static final String REDIRECT_URL = "http://www.devtf.cn";
    public static final String SCOPE = "email,direct_messages_read,direct_messages_write,"
            + "friendships_groups_read,friendships_groups_write,statuses_to_me_read,"
            + "follow_app_official_microblog";
    public static String SINA_UID_TOKEN = "https://api.weibo.com/2/users/show.json?uid=";
    public static final String PREFS_NAME = "UserInfo";
}
